from flask import Flask, render_template, request
import requests
from datetime import datetime
from collections import defaultdict

app = Flask(__name__)

API_KEY = 'b2aa940a64be17f4b1794704226fcc82'

@app.route('/', methods=['GET', 'POST'])
def index():
    weather_data = None
    error_message = None
    selected_days = 5  # по умолчанию 5 дней
    city = None

    if request.method == 'POST':
        city = request.form.get('city')
        days = request.form.get('days', '5')
        selected_days = int(days) if days in ['1', '5'] else 5

        if not city:
            error_message = "Пожалуйста, введите название города."
        else:
            url_forecast = f"http://api.openweathermap.org/data/2.5/forecast?q={city}&appid={API_KEY}&units=metric&lang=ru"
            try:
                response = requests.get(url_forecast)
                response.raise_for_status()
                data = response.json()

                if data.get("cod") != "200":
                    error_message = f'Такого города "{city}" не существует. Попробуйте еще раз.'
                else:
                    daily_data = defaultdict(list)
                    for entry in data['list']:
                        date = entry['dt_txt'].split(' ')[0]
                        daily_data[date].append(entry)

                    weather_data = []

                    # если выбран 1 день, берем первый день из данных
                    dates = list(daily_data.keys())
                    if selected_days == 1:
                        dates = dates[:1]
                    else:
                        dates = dates[:5]

                    for date in dates:
                        entries = daily_data[date]
                        temps = [e['main']['temp'] for e in entries]
                        humidities = [e['main']['humidity'] for e in entries]
                        descriptions = [e['weather'][0]['description'] for e in entries]
                        icons = [e['weather'][0]['icon'] for e in entries]

                        day_weather = {
                            'date': datetime.strptime(date, "%Y-%m-%d").strftime('%d-%m-%Y'),
                            'temp_day': round(max(temps), 1),
                            'temp_night': round(min(temps), 1),
                            'humidity': round(sum(humidities) / len(humidities)),
                            'description': max(set(descriptions), key=descriptions.count),
                            'icon': max(set(icons), key=icons.count)  # выбираем наиболее частую иконку
                        }
                        weather_data.append(day_weather)

            except requests.exceptions.HTTPError as http_err:
                if http_err.response.status_code == 404:
                    error_message = f'Такого города "{city}" не существует. Попробуйте еще раз.'
                else:
                    error_message = f"Ошибка HTTP: {http_err}"
            except requests.exceptions.RequestException as e:
                error_message = f"Ошибка при получении данных: {e}"

    return render_template('index.html', weather=weather_data, error=error_message, selected_days=selected_days, city=city)


if __name__ == '__main__':
    app.run(debug=True)
